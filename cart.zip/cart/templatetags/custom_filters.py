from django import template

register = template.Library()

@register.filter
def multiply(value, arg):
    """Multiplies the value by the given argument."""
    try:
        return float(value) * float(arg)
    except (ValueError, TypeError):
        return None

@register.filter
def get_range(value):
    return range(int(value))

@register.filter
def total_cart_price(cart_items):
    return sum(item.ticket_details.price * item.quantity for item in cart_items)