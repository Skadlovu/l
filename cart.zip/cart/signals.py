from django.contrib.auth.signals import user_logged_in
from django.dispatch import receiver
from .models import CartItem
from.services import CartService
import logging
logger = logging.getLogger(__name__)
from django.db import transaction



@receiver(user_logged_in)
def transfer_cart_on_login(sender, user, request, **kwargs):
    """
    Transfer session-based cart items to user's cart upon login.
    Only transfers, no redirection or UI messages to ensure seamless login.
    """
    try:
        with transaction.atomic():
            if not hasattr(user, 'customer'):
                return
            
            session_key = request.session.session_key
            if not session_key:
                return
            
            # Transfer session-based cart items to user cart
            session_cart_items = CartItem.objects.filter(session_key=session_key)
            for session_item in session_cart_items:
                user_cart_item, created = CartItem.objects.get_or_create(
                    customer=user.customer,
                    ticket_details=session_item.ticket_details,
                    defaults={'quantity': session_item.quantity}
                )
                
                if not created:
                    user_cart_item.quantity += session_item.quantity
                    user_cart_item.save()
                
                # Remove session cart item after transfer
                session_item.delete()

    except Exception as e:
        print(f"Error transferring cart items: {str(e)}")